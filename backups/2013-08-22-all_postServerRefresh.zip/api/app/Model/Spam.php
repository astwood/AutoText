<?php
App::uses('Model', 'Model');

class Spam extends AppModel {
    
    public $displayField = 'word';
    
}
